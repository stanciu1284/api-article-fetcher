<?php
/*
Plugin Name: API Article Fetcher
Description: A plugin to fetch new articles from an API every 3 minutes and add them as WordPress posts.
Version: 1.0
Author: Florică Stanciu
*/

// Asigură-te că nu este accesibil direct
if (!defined('ABSPATH')) {
    exit;
}

// Funcție pentru a apela API-ul și a adăuga articole noi
function aaf_fetch_and_create_articles() {
    $api_url = 'https://strapi.fstanciu.ro/api/posts/'; // Endpoint-ul API
    $bearer_token = 'Bearer 12ed7b52c0e0b18f0fb1969b5dc251e14aeb03dc27a8f30906d35a428833cb018aecf5a9d893794d89bf431e093d72ffe103a42abf9580717b7aa7c1adfb1cdddbd316e444c37b630dcc8f2af25f0f0ac40ecee9b885e0c10b24a5ba502f3f355c75fa3eb4331ad420e81f9e2469eb285db9acb55e59bcc5c32145f53149bd0b';

    // Inițializează o cerere cURL pentru a apela API-ul
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Authorization: ' . $bearer_token
    ));

    // Execută cererea și decodează răspunsul JSON
    $response = curl_exec($ch);
    curl_close($ch);

    if ($response === false) {
        error_log('API request failed');
        return;
    }

    $posts = json_decode($response, true);

    // Verifică dacă răspunsul conține date valide
    if (isset($posts['data']) && is_array($posts['data'])) {
        foreach ($posts['data'] as $post_data) {
            // Extrage datele din structura postului
            $title = $post_data['attributes']['title'] ?? 'No title';
            $body = $post_data['attributes']['body'] ?? '';
            $slug = $post_data['attributes']['slug'] ?? '';
            $published_at = $post_data['attributes']['publishedAt'] ?? '';
			$categories = $post_data['attributes']['category'] ?? [];
			$tags = $post_data['attributes']['tag'] ?? [];
			$featured_image_url = $post_data['attributes']['img_url'] ?? '';

            // Verifică dacă articolul există deja pe baza slug-ului
            if (get_page_by_path($slug, OBJECT, 'post')) {
                continue; // Dacă postul există, continuăm la următorul.
            }

            // Creează un nou articol în WordPress
            $new_post = array(
                'post_title'   => wp_strip_all_tags($title),
                'post_content' => $body,
                'post_status'  => 'publish',
                'post_name'    => $slug,
                'post_date'    => $published_at,
                'post_type'    => 'post'
            );

            // Inserează articolul în baza de date
            $post_id = wp_insert_post($new_post);
			
			if ($post_id) {
                error_log('Post inserted successfully: ' . $title);

                // Adaugă categoriile multiple
                if (!empty($categories)) {
                    set_post_categories_by_names($post_id, $categories);
                }
				// Adaugă tag-urile
                if (!empty($tags)) {
                    wp_set_post_tags($post_id, $tags, true);
                }
				// Setează imaginea featured
                if (!empty($featured_image_url)) {
                    set_featured_image($post_id, $featured_image_url);
                }

            } else {
                error_log('Failed to insert post: ' . $title);
            }
        }
    } else {
        error_log('Invalid API response');
    }
}

function set_post_categories_by_names($post_id, $category_names) {
    $category_ids = array();

    foreach ($category_names as $category_name) {
        $category_id = get_cat_ID($category_name);

        if ($category_id == 0) {
            $category_id = wp_create_category($category_name);
            error_log('Category created: ' . $category_name);
        }

        $category_ids[] = $category_id;
    }

    wp_set_post_categories($post_id, $category_ids);
    error_log('Categories set for post ID: ' . $post_id . ' - ' . implode(', ', $category_names));
}

function set_featured_image($post_id, $image_url) {
    // Încearcă să descarci imaginea
    $tmp = download_url($image_url);

    if (is_wp_error($tmp)) {
        error_log('Failed to download image: ' . $image_url . ' Error: ' . $tmp->get_error_message());
        return;
    }

    // Creează un array pentru imagine
    $file_array = array(
        'name'     => basename($image_url),
        'tmp_name' => $tmp
    );

    // Încarcă imaginea și gestionează eventuale erori
    $attachment_id = media_handle_sideload($file_array, $post_id);

    if (is_wp_error($attachment_id)) {
        error_log('Failed to sideload image for post ID: ' . $post_id . ' Error: ' . $attachment_id->get_error_message());
        @unlink($file_array['tmp_name']); // Sterge fișierul temporar
    } else {
        set_post_thumbnail($post_id, $attachment_id);
        error_log('Featured image set successfully for post ID: ' . $post_id);
    }
}

// Setăm un cron job pentru a apela funcția la fiecare 3 minute
function aaf_schedule_article_fetch() {
    if (!wp_next_scheduled('aaf_fetch_articles_event')) {
        wp_schedule_event(time(), 'every_three_minutes', 'aaf_fetch_articles_event');
    }
}

// Adaugă o nouă frecvență la cron pentru 3 minute
function aaf_custom_cron_schedule($schedules) {
    $schedules['every_three_minutes'] = array(
        'interval' => 180,  // 180 secunde = 3 minute
        'display'  => esc_html__('Every 3 Minutes'),
    );
    return $schedules;
}

// Când cron-ul este declanșat, apelează funcția de fetch
add_action('aaf_fetch_articles_event', 'aaf_fetch_and_create_articles');

// Hook-uri pentru a porni și opri cron job-ul când pluginul este activat/dezactivat
register_activation_hook(__FILE__, 'aaf_schedule_article_fetch');
add_filter('cron_schedules', 'aaf_custom_cron_schedule');

// Funcție pentru a elimina cron job-ul la dezactivarea pluginului
function aaf_deactivate_plugin() {
    $timestamp = wp_next_scheduled('aaf_fetch_articles_event');
    wp_unschedule_event($timestamp, 'aaf_fetch_articles_event');
}
register_deactivation_hook(__FILE__, 'aaf_deactivate_plugin');
